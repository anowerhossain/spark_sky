# Bank Lakehouse Spark ETL

This project is a local, configuration-driven Spark ETL framework for a bank lakehouse. It creates dummy bronze banking tables in Apache Iceberg format, builds two silver tables, and then builds one gold table.

The main idea: the Python code is generic. To add a new table, add configuration and SQL files. You do not need to create a new job class.

## Local Pipeline

The sample pipeline in `configs/bank_lakehouse.yaml` creates:

| Layer | Table | Purpose |
| --- | --- | --- |
| Bronze | `bank.bronze.customers` | Dummy source customers |
| Bronze | `bank.bronze.accounts` | Dummy source accounts |
| Bronze | `bank.bronze.transactions` | Dummy source transactions |
| Bronze | `bank.bronze.branches` | Dummy branch reference data |
| Bronze | `bank.bronze.products` | Dummy product reference data |
| Silver | `bank.silver.customer_account` | Customer/account enriched table |
| Silver | `bank.silver.transaction_daily` | Daily posted transaction summary |
| Gold | `bank.gold.customer_balance` | Customer balance and activity aggregate |

The bronze layer is seeded from CSV files under `data/raw/`. In a real environment, these bronze tables can be replaced by Qlik Replicate outputs from Oracle.

## Project Layout

```text
configs/bank_lakehouse.yaml        # Pipeline, Spark, job, DQ, and load config
data/raw/                          # Local dummy bronze input data
sql/create_tables/bronze/          # Bronze Iceberg DDL
sql/create_tables/silver/          # Silver Iceberg DDL
sql/create_tables/gold/            # Gold Iceberg DDL
sql/load_scripts/bronze/           # Bronze load SELECT SQL
sql/load_scripts/silver/           # Silver Spark SQL transformations
sql/load_scripts/gold/             # Gold Spark SQL transformations
src/etl_pipeline/core/executor.py  # Main sequenced/parallel/retry runner
src/etl_pipeline/jobs/lakehouse.py # Single generic config-driven job class
src/etl_pipeline/quality/engine.py # Data quality framework
```

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

The local config uses Spark 3.5 with Iceberg:

```yaml
spark.jars.packages: org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.2
spark.sql.catalog.bank: org.apache.iceberg.spark.SparkCatalog
spark.sql.catalog.bank.type: hadoop
spark.sql.catalog.bank.warehouse: data/lakehouse/warehouse
spark.sql.extensions: org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions
```

On a bank-managed platform, replace these with the approved catalog, warehouse, metastore, and runtime settings.

The sample uses Iceberg `1.5.2` because this local machine is running Spark with Java 11. Newer Iceberg releases may require Java 17.

## Run

Validate the pipeline plan without starting Spark:

```bash
python main.py --dry-run
```

Run the full local pipeline:

```bash
python main.py --config configs/bank_lakehouse.yaml
```

Run one job and its upstream dependencies:

```bash
python main.py --job gold_customer_balance
```

Outputs:

- Iceberg warehouse: `data/lakehouse/warehouse/`
- Data quality quarantine files: `data/lakehouse/quarantine/`
- Logs: `logs/`

## Execution Model

Each job has a user-defined `sequence`. Jobs in lower sequences run first.

```yaml
sequence: 10
order: 1
depends_on:
  - bronze_customers
execution:
  parallel: true
```

Rules:

- Jobs in the same sequence can run in parallel only when `execution.parallel: true`.
- `max_parallel_jobs` controls the maximum number of concurrent jobs.
- A job starts only after all `depends_on` jobs complete.
- If a job fails after all retries, all downstream jobs stop.

## Retry

Retry is configured per job:

```yaml
retry:
  max_attempts: 3
  delay_seconds: 10
  backoff_multiplier: 2
```

## Load Methods

### INSERT

Used for append/overwrite style loads.

```yaml
load:
  method: INSERT
  insert_mode: OVERWRITE
  staging_view: stg_gold_customer_balance
```

For local seed jobs, `truncate_before_insert: true` makes repeated runs idempotent:

```yaml
load:
  method: INSERT
  insert_mode: INTO
  truncate_before_insert: true
```

### MERGE / UPSERT

Used for business-key upserts into Iceberg tables.

```yaml
load:
  method: MERGE
  business_keys: [account_id]
  staging_view: stg_silver_customer_account
```

The framework generates the `MERGE INTO` SQL from the configured target columns and business keys.

## Transformation Types

### Spark SQL

```yaml
transformation:
  api: spark_sql
  load_sql_path: sql/load_scripts/silver/customer_account.sql
```

### DataFrame API

```yaml
transformation:
  api: dataframe
  dataframe:
    base_view: bronze_transactions
    filter: "transaction_status = 'POSTED'"
    group_by: [account_id, transaction_date, currency]
    aggregations:
      - name: debit_amount
        expression: "sum(CASE WHEN dr_cr = 'D' THEN amount ELSE 0 END)"
```

## Data Quality

Data quality rules are configured per job and run before the target load.

```yaml
quality:
  fail_fast: true
  quarantine:
    path: data/lakehouse/quarantine/silver/customer_account
    format: parquet
    mode: overwrite
  rules:
    - name: account_id_required
      type: not_null
      column: account_id
    - name: account_id_unique
      type: unique
      column: account_id
```

Supported rules:

- `not_null`
- `unique`
- `regex`
- `accepted_values`
- `min_value`
- `max_value`
- `expression`

## Add A New Pipeline Job

1. Add input data or make sure the source table already exists.
2. Add a job block under `pipeline.jobs` in `configs/bank_lakehouse.yaml`.
3. Set `name`, `layer`, `sequence`, `depends_on`, `execution`, and `retry`.
4. Add `sources` and give each source a temp view name.
5. Choose `transformation.api`: `spark_sql` or `dataframe`.
6. Add `target.table`, `target.create_table_sql_path`, and `target.columns`.
7. Choose `load.method`: `INSERT` or `MERGE`.
8. Add `quality.rules`.
9. Run `python main.py --dry-run`.
10. Run `python main.py --job <new_job_name>`.

Minimal Spark SQL job shape:

```yaml
- name: silver_new_table
  enabled: true
  layer: silver
  sequence: 10
  order: 3
  depends_on: [bronze_some_table]
  execution:
    parallel: true
  retry:
    max_attempts: 2
    delay_seconds: 5
  sources:
    - view: bronze_some_table
      type: table
      table: bank.bronze.some_table
  transformation:
    api: spark_sql
    load_sql_path: sql/load_scripts/silver/new_table.sql
  target:
    table: bank.silver.new_table
    format: iceberg
    create_table_sql_path: sql/create_tables/silver/new_table.sql
    columns:
      - name: business_id
        source: business_id
        data_type: string
  load:
    method: MERGE
    business_keys: [business_id]
  quality:
    fail_fast: true
    rules:
      - name: business_id_required
        type: not_null
        column: business_id
```

## Tests

```bash
pytest -q
```

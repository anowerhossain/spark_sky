from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from etl_pipeline.config.loader import load_pipeline_config
from etl_pipeline.core.executor import PipelineExecutor
from etl_pipeline.core.logging import configure_logging
from etl_pipeline.core.spark import build_spark_session


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a configurable Spark ETL pipeline.")
    parser.add_argument(
        "--config",
        default="configs/bank_lakehouse.yaml",
        help="Path to the pipeline YAML configuration.",
    )
    parser.add_argument(
        "--job",
        help="Run one job and all of its upstream dependencies.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate the DAG and print the execution plan without starting Spark.",
    )
    parser.add_argument(
        "--log-level",
        default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Override configured log level.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config = load_pipeline_config(Path(args.config))

    log_level = args.log_level or config.get("pipeline", {}).get("log_level", "INFO")
    log_file = configure_logging(config["pipeline"]["name"], log_level)
    logger = logging.getLogger(__name__)
    logger.info("Loaded pipeline config from %s", args.config)
    logger.info("Writing logs to %s", log_file)

    executor = PipelineExecutor(config)
    execution_plan = executor.plan(target_job=args.job)

    if args.dry_run:
        logger.info("Dry run requested; Spark session will not be created.")
        print("Execution plan:")
        for level_number, level in enumerate(execution_plan, start=1):
            print(f"  Level {level_number}: {', '.join(level)}")
        return 0

    spark = build_spark_session(config)
    try:
        results = executor.run(spark, target_job=args.job)
        logger.info("Pipeline completed successfully with %d job(s).", len(results))
        for job_name, result in results.items():
            logger.info("Result[%s]: %s", job_name, result)
        return 0
    except Exception:
        logger.exception("Pipeline failed.")
        return 1
    finally:
        spark.stop()
        logger.info("Spark session stopped.")


if __name__ == "__main__":
    sys.exit(main())

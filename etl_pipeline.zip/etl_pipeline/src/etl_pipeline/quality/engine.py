from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


@dataclass
class DataQualityResult:
    valid_df: DataFrame
    invalid_df: DataFrame
    bad_rows: int
    metrics: dict[str, Any] = field(default_factory=dict)


class DataQualityEngine:
    def __init__(self, config: dict[str, Any], job_name: str) -> None:
        self.config = config or {}
        self.job_name = job_name
        self.rules = self.config.get("rules", [])

    def apply(self, df: DataFrame, spark: SparkSession) -> DataQualityResult:
        if not self.rules:
            empty_invalid = self._empty_invalid_df(df, spark)
            return DataQualityResult(
                valid_df=df,
                invalid_df=empty_invalid,
                bad_rows=0,
                metrics={"rules_evaluated": 0, "violations_by_rule": {}},
            )

        df_with_id = df.withColumn("_dq_row_id", F.monotonically_increasing_id())
        violations = []

        for rule in self.rules:
            rule_name = rule["name"]
            invalid_rows = self._invalid_rows_for_rule(df_with_id, rule)
            invalid_rows = invalid_rows.withColumn("_dq_rule", F.lit(rule_name))
            violations.append(invalid_rows)

        invalid_df = violations[0]
        for frame in violations[1:]:
            invalid_df = invalid_df.unionByName(frame)

        invalid_df = invalid_df.withColumn("_dq_job", F.lit(self.job_name)).withColumn(
            "_dq_checked_at", F.current_timestamp()
        )
        bad_ids = invalid_df.select("_dq_row_id").distinct()
        valid_df = df_with_id.join(bad_ids, on="_dq_row_id", how="left_anti").drop("_dq_row_id")

        rule_counts = {
            row["_dq_rule"]: row["count"]
            for row in invalid_df.groupBy("_dq_rule").count().collect()
        }
        bad_rows = sum(rule_counts.values())

        return DataQualityResult(
            valid_df=valid_df,
            invalid_df=invalid_df.drop("_dq_row_id"),
            bad_rows=bad_rows,
            metrics={
                "rules_evaluated": len(self.rules),
                "violations_by_rule": rule_counts,
            },
        )

    def _invalid_rows_for_rule(self, df: DataFrame, rule: dict[str, Any]) -> DataFrame:
        rule_type = rule["type"]

        if rule_type == "not_null":
            condition = F.col(rule["column"]).isNull()
        elif rule_type == "regex":
            condition = ~F.col(rule["column"]).rlike(rule["pattern"])
        elif rule_type == "accepted_values":
            condition = ~F.col(rule["column"]).isin(rule["values"])
        elif rule_type == "min_value":
            condition = F.col(rule["column"]) < F.lit(rule["value"])
        elif rule_type == "max_value":
            condition = F.col(rule["column"]) > F.lit(rule["value"])
        elif rule_type == "expression":
            condition = ~(F.expr(rule["expression"]))
        elif rule_type == "unique":
            return self._duplicate_rows(df, rule)
        else:
            raise ValueError(f"Unsupported data-quality rule type: {rule_type}")

        return df.where(condition | condition.isNull())

    def _duplicate_rows(self, df: DataFrame, rule: dict[str, Any]) -> DataFrame:
        columns = rule.get("columns") or [rule["column"]]
        duplicates = (
            df.groupBy(*columns)
            .count()
            .where(F.col("count") > 1)
            .drop("count")
        )
        return df.join(duplicates, on=columns, how="inner")

    def _empty_invalid_df(self, df: DataFrame, spark: SparkSession) -> DataFrame:
        invalid_schema = df.schema.add("_dq_rule", "string").add("_dq_job", "string")
        invalid_schema = invalid_schema.add("_dq_checked_at", "timestamp")
        return spark.createDataFrame([], invalid_schema)

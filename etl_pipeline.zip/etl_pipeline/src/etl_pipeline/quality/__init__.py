"""Reusable data-quality rules for Spark DataFrames."""

from __future__ import annotations

from typing import Any

from pyspark.sql import SparkSession


def build_spark_session(config: dict[str, Any]) -> SparkSession:
    spark_config = config["pipeline"].get("spark", {})
    app_name = spark_config.get("app_name", config["pipeline"]["name"])
    master = spark_config.get("master")

    builder = SparkSession.builder.appName(app_name)
    if master:
        builder = builder.master(master)

    for key, value in spark_config.get("configs", {}).items():
        builder = builder.config(key, str(value))

    spark = builder.getOrCreate()
    spark.sparkContext.setLogLevel(spark_config.get("log_level", "WARN"))
    return spark

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from time import perf_counter, sleep
from typing import Any

from pyspark.sql import SparkSession

from etl_pipeline.jobs.base import JobResult
from etl_pipeline.jobs.lakehouse import ConfigDrivenLakehouseJob

logger = logging.getLogger(__name__)


@dataclass
class PipelineContext:
    pipeline_name: str
    config: dict[str, Any]
    results: dict[str, JobResult] = field(default_factory=dict)


class PipelineExecutor:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.pipeline = config["pipeline"]
        self.jobs = {
            job["name"]: job
            for job in self.pipeline["jobs"]
            if job.get("enabled", True)
        }
        self._validate_dag()

    def plan(self, target_job: str | None = None) -> list[list[str]]:
        selected = self._selected_jobs(target_job)
        levels: dict[int, list[str]] = {}
        for job_name in selected:
            sequence = int(self.jobs[job_name]["sequence"])
            levels.setdefault(sequence, []).append(job_name)

        return [
            sorted(names, key=lambda name: (self.jobs[name].get("order", 999_999), name))
            for _, names in sorted(levels.items())
        ]

    def run(self, spark: SparkSession, target_job: str | None = None) -> dict[str, JobResult]:
        max_workers = int(self.pipeline.get("max_parallel_jobs", 1))
        context = PipelineContext(self.pipeline["name"], self.config)
        completed: set[str] = set()
        started_at = perf_counter()
        plan = self.plan(target_job)

        logger.info(
            "Starting pipeline=%s execution_plan=%s max_parallel_jobs=%s",
            self.pipeline["name"],
            plan,
            max_workers,
        )

        for level_index, level in enumerate(plan, start=1):
            self._assert_dependencies_complete(level, completed)
            logger.info("Starting sequence_level=%d jobs=%s", level_index, level)

            if self._can_run_level_in_parallel(level, max_workers):
                self._run_parallel_level(level, spark, context, completed, max_workers)
            else:
                for job_name in level:
                    result = self._run_job_with_retries(job_name, spark, context)
                    context.results[job_name] = result
                    completed.add(job_name)
                    logger.info("Job completed: %s", job_name)

        elapsed = perf_counter() - started_at
        logger.info("Pipeline=%s finished in %.2fs", self.pipeline["name"], elapsed)
        return context.results

    def _run_parallel_level(
        self,
        level: list[str],
        spark: SparkSession,
        context: PipelineContext,
        completed: set[str],
        max_workers: int,
    ) -> None:
        logger.info("Running sequence level in parallel: %s", level)
        with ThreadPoolExecutor(
            max_workers=min(max_workers, len(level)),
            thread_name_prefix="etl-job",
        ) as pool:
            futures = {
                pool.submit(self._run_job_with_retries, job_name, spark, context): job_name
                for job_name in level
            }
            for future in as_completed(futures):
                job_name = futures[future]
                try:
                    result = future.result()
                except Exception as exc:
                    logger.exception(
                        "Job=%s failed after retry policy; stopping downstream jobs.",
                        job_name,
                    )
                    raise RuntimeError(
                        f"Pipeline stopped because job {job_name} failed."
                    ) from exc
                context.results[job_name] = result
                completed.add(job_name)
                logger.info("Job completed: %s", job_name)

    def _run_job_with_retries(
        self,
        job_name: str,
        spark: SparkSession,
        context: PipelineContext,
    ) -> JobResult:
        job_config = self.jobs[job_name]
        retry_config = job_config.get("retry", {})
        max_attempts = int(retry_config.get("max_attempts", 1))
        delay_seconds = float(retry_config.get("delay_seconds", 0))
        backoff_multiplier = float(retry_config.get("backoff_multiplier", 1))
        attempt = 1

        while attempt <= max_attempts:
            try:
                logger.info(
                    "Running job=%s attempt=%d/%d sequence=%s parallel=%s",
                    job_name,
                    attempt,
                    max_attempts,
                    job_config["sequence"],
                    job_config.get("execution", {}).get("parallel", False),
                )
                job = ConfigDrivenLakehouseJob(job_config)
                result = job.run(spark, context)
                result.attempts = attempt
                return result
            except Exception:
                logger.exception("Job=%s failed attempt=%d/%d", job_name, attempt, max_attempts)
                if attempt >= max_attempts:
                    raise
                retry_delay = delay_seconds * (backoff_multiplier ** (attempt - 1))
                logger.info("Retrying job=%s after %.2fs", job_name, retry_delay)
                if retry_delay > 0:
                    sleep(retry_delay)
                attempt += 1

        raise RuntimeError(f"Retry loop exited unexpectedly for job {job_name}.")

    def _can_run_level_in_parallel(self, level: list[str], max_workers: int) -> bool:
        if len(level) <= 1 or max_workers <= 1:
            return False
        return all(self.jobs[job].get("execution", {}).get("parallel", False) for job in level)

    def _assert_dependencies_complete(self, level: list[str], completed: set[str]) -> None:
        for job_name in level:
            missing = set(self.jobs[job_name].get("depends_on", [])) - completed
            if missing:
                raise RuntimeError(
                    f"Job {job_name} cannot start; dependencies not completed: {sorted(missing)}"
                )

    def _selected_jobs(self, target_job: str | None) -> set[str]:
        if target_job is None:
            return set(self.jobs)
        if target_job not in self.jobs:
            raise ValueError(f"Unknown or disabled target job: {target_job}")

        selected: set[str] = set()

        def visit(job_name: str) -> None:
            if job_name in selected:
                return
            for dependency in self.jobs[job_name].get("depends_on", []):
                visit(dependency)
            selected.add(job_name)

        visit(target_job)
        return selected

    def _validate_dag(self) -> None:
        all_jobs = set(self.jobs)
        for job_name, job_config in self.jobs.items():
            for dependency in job_config.get("depends_on", []):
                if dependency not in all_jobs:
                    raise ValueError(
                        f"Enabled job {job_name} depends on missing or disabled job {dependency}."
                    )

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(job_name: str) -> None:
            if job_name in visited:
                return
            if job_name in visiting:
                raise ValueError(f"Cycle detected at job {job_name}.")
            visiting.add(job_name)
            for dependency in self.jobs[job_name].get("depends_on", []):
                visit(dependency)
            visiting.remove(job_name)
            visited.add(job_name)

        for job_name in self.jobs:
            visit(job_name)

        for job_name, job_config in self.jobs.items():
            job_sequence = int(job_config["sequence"])
            for dependency in job_config.get("depends_on", []):
                dependency_sequence = int(self.jobs[dependency]["sequence"])
                if dependency_sequence >= job_sequence:
                    raise ValueError(
                        f"Job {job_name} sequence must be greater than dependency {dependency}."
                    )

"""Core pipeline orchestration components."""

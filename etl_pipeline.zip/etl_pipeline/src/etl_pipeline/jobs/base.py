from __future__ import annotations

import logging
from dataclasses import dataclass, field
from time import perf_counter
from typing import Any

from pyspark.sql import DataFrame, SparkSession

from etl_pipeline.quality.engine import DataQualityEngine


@dataclass
class JobResult:
    name: str
    status: str
    attempts: int = 1
    rows_read: int = 0
    rows_written: int = 0
    bad_rows: int = 0
    target: str | None = None
    elapsed_seconds: float = 0.0
    metrics: dict[str, Any] = field(default_factory=dict)


class BaseSparkJob:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.name = config["name"]
        self.logger = logging.getLogger(f"{self.__class__.__module__}.{self.name}")

    def run(self, spark: SparkSession, context) -> JobResult:
        started_at = perf_counter()
        self.logger.info("Starting job=%s class=%s", self.name, self.__class__.__name__)
        try:
            result = self.execute(spark, context)
            result.elapsed_seconds = perf_counter() - started_at
            self.logger.info("Finished job=%s result=%s", self.name, result)
            return result
        except Exception:
            self.logger.exception("Job failed: %s", self.name)
            raise

    def execute(self, spark: SparkSession, context) -> JobResult:
        raise NotImplementedError

    def read_source(self, spark: SparkSession, source: dict[str, Any]) -> DataFrame:
        source_type = source.get("type", "file")
        self.logger.debug("Reading source type=%s config=%s", source_type, source)

        if source_type == "file":
            reader = spark.read.format(source["format"])
            reader = reader.options(**source.get("options", {}))
            return reader.load(source["path"])
        if source_type == "table":
            return spark.table(source["name"])

        raise ValueError(f"Unsupported source type: {source_type}")

    def write_target(self, df: DataFrame, target: dict[str, Any]) -> str:
        target_type = target.get("type", "file")
        writer = df.write.format(target.get("format", "parquet")).mode(target.get("mode", "error"))
        writer = writer.options(**target.get("options", {}))

        partition_by = target.get("partition_by", [])
        if partition_by:
            writer = writer.partitionBy(*partition_by)

        if target_type == "file":
            path = target["path"]
            self.logger.debug("Writing file target=%s", target)
            writer.save(path)
            return path
        if target_type == "table":
            table_name = target["name"]
            self.logger.debug("Writing table target=%s", target)
            writer.saveAsTable(table_name)
            return table_name

        raise ValueError(f"Unsupported target type: {target_type}")

    def apply_quality(self, df: DataFrame, spark: SparkSession) -> tuple[DataFrame, int, dict[str, Any]]:
        quality_config = self.config.get("quality", {})
        engine = DataQualityEngine(quality_config, self.name)
        quality_result = engine.apply(df, spark)

        if quality_result.bad_rows and quality_config.get("quarantine"):
            quarantine = quality_config["quarantine"]
            quarantine_target = {
                "type": "file",
                "format": quarantine.get("format", "parquet"),
                "mode": quarantine.get("mode", "overwrite"),
                "path": quarantine["path"],
                "options": quarantine.get("options", {}),
            }
            self.logger.warning(
                "Writing %d bad row violation(s) to quarantine path=%s",
                quality_result.bad_rows,
                quarantine_target["path"],
            )
            self.write_target(quality_result.invalid_df, quarantine_target)

        if quality_result.bad_rows and quality_config.get("fail_fast", False):
            raise ValueError(
                f"Job {self.name} failed data quality with {quality_result.bad_rows} violation(s)."
            )

        return quality_result.valid_df, quality_result.bad_rows, quality_result.metrics

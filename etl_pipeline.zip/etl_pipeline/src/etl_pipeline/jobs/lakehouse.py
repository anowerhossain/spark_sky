from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from etl_pipeline.jobs.base import BaseSparkJob, JobResult


class ConfigDrivenLakehouseJob(BaseSparkJob):
    """One generic Spark job class driven by YAML and optional SQL files."""

    def execute(self, spark: SparkSession, context) -> JobResult:
        self._log_config_summary()
        self._register_sources(spark)
        self._ensure_target_table(spark)

        df = self._build_input_dataframe(spark)
        rows_read = df.count()
        self.logger.info("Transformation produced %d row(s) before column alignment.", rows_read)

        df = self._apply_static_audit_columns(df)
        df = self._align_to_destination_columns(df)

        valid_df, bad_rows, quality_metrics = self.apply_quality(df, spark)
        rows_written = valid_df.count()

        self._load_target(spark, valid_df)

        return JobResult(
            name=self.name,
            status="success",
            rows_read=rows_read,
            rows_written=rows_written,
            bad_rows=bad_rows,
            target=self.target_table,
            metrics={
                "quality": quality_metrics,
                "load_method": self.load_method,
                "api": self.transformation_api,
            },
        )

    @property
    def target_table(self) -> str:
        return self.config["target"]["table"]

    @property
    def load_method(self) -> str:
        return self.config["load"]["method"].upper()

    @property
    def transformation_api(self) -> str:
        return self.config.get("transformation", {}).get("api", "spark_sql")

    def _log_config_summary(self) -> None:
        self.logger.info(
            "Job config summary name=%s layer=%s target=%s api=%s load_method=%s",
            self.name,
            self.config.get("layer"),
            self.target_table,
            self.transformation_api,
            self.load_method,
        )

    def _register_sources(self, spark: SparkSession) -> None:
        for source in self.config.get("sources", []):
            view_name = source["view"]
            source_type = source.get("type", "table")
            self.logger.info("Registering source view=%s type=%s", view_name, source_type)

            if source_type == "table":
                df = spark.table(source["table"])
            elif source_type == "file":
                reader = spark.read.format(source["format"]).options(**source.get("options", {}))
                df = reader.load(source["path"])
            elif source_type == "sql":
                df = spark.sql(self._read_text(source["sql_path"]))
            else:
                raise ValueError(f"Unsupported source type: {source_type}")

            df.createOrReplaceTempView(view_name)
            self.logger.info("Registered view=%s columns=%s", view_name, df.columns)

    def _ensure_target_table(self, spark: SparkSession) -> None:
        if self._table_exists(spark, self.target_table):
            self.logger.info("Target table already exists: %s", self.target_table)
            return

        self.logger.info("Target table does not exist; creating table=%s", self.target_table)
        self._ensure_target_namespace(spark)
        create_sql_path = self.config.get("target", {}).get("create_table_sql_path")
        create_sql = self._read_text(create_sql_path) if create_sql_path else self._generate_create_table_sql()
        create_sql = self._render_sql(create_sql)
        self.logger.debug("Create table SQL for %s:\n%s", self.target_table, create_sql)
        spark.sql(create_sql)
        self.logger.info("Created target table=%s", self.target_table)

    def _ensure_target_namespace(self, spark: SparkSession) -> None:
        parts = self.target_table.split(".")
        if len(parts) < 3:
            return
        namespace = ".".join(parts[:-1])
        self.logger.info("Ensuring target namespace exists: %s", namespace)
        spark.sql(f"CREATE NAMESPACE IF NOT EXISTS {namespace}")

    def _build_input_dataframe(self, spark: SparkSession) -> DataFrame:
        if self.transformation_api == "spark_sql":
            return self._run_sql_transformation(spark)
        if self.transformation_api == "dataframe":
            return self._run_dataframe_transformation(spark)
        raise ValueError(f"Unsupported transformation API: {self.transformation_api}")

    def _run_sql_transformation(self, spark: SparkSession) -> DataFrame:
        transformation = self.config.get("transformation", {})
        sql_path = transformation.get("load_sql_path")
        sql_text = self._read_text(sql_path) if sql_path else transformation["sql"]
        sql_text = self._render_sql(sql_text)
        self.logger.debug("Running Spark SQL transformation for job=%s:\n%s", self.name, sql_text)
        return spark.sql(sql_text)

    def _run_dataframe_transformation(self, spark: SparkSession) -> DataFrame:
        transformation = self.config.get("transformation", {})
        dataframe_config = transformation.get("dataframe", {})

        if dataframe_config.get("custom_function"):
            return self._run_custom_dataframe_function(spark, dataframe_config["custom_function"])

        base_view = dataframe_config["base_view"]
        df = spark.table(base_view)
        self.logger.info("Running DataFrame API transformation from base_view=%s", base_view)

        for join in dataframe_config.get("joins", []):
            right = spark.table(join["view"])
            condition = F.expr(join["condition"])
            df = df.join(right, condition, join.get("type", "inner"))
            self.logger.info("Applied DataFrame join view=%s type=%s", join["view"], join.get("type", "inner"))

        if dataframe_config.get("filter"):
            df = df.where(F.expr(dataframe_config["filter"]))
            self.logger.info("Applied DataFrame filter=%s", dataframe_config["filter"])

        if dataframe_config.get("group_by"):
            group_cols = [F.col(col) for col in dataframe_config["group_by"]]
            aggregates = [
                F.expr(aggregate["expression"]).alias(aggregate["name"])
                for aggregate in dataframe_config.get("aggregations", [])
            ]
            df = df.groupBy(*group_cols).agg(*aggregates)
            self.logger.info("Applied DataFrame group_by=%s", dataframe_config["group_by"])

        select_expressions = dataframe_config.get("select")
        if select_expressions:
            df = df.select(
                *[
                    F.expr(item["expression"]).alias(item.get("alias", item["expression"]))
                    for item in select_expressions
                ]
            )
            self.logger.info("Applied DataFrame select with %d expression(s)", len(select_expressions))

        return df

    def _run_custom_dataframe_function(self, spark: SparkSession, function_path: str) -> DataFrame:
        module_name, _, function_name = function_path.rpartition(".")
        if not module_name:
            raise ValueError(f"Invalid custom_function path: {function_path}")
        module = __import__(module_name, fromlist=[function_name])
        function = getattr(module, function_name)
        self.logger.info("Running custom DataFrame function=%s", function_path)
        return function(spark=spark, job_config=self.config, logger=self.logger)

    def _align_to_destination_columns(self, df: DataFrame) -> DataFrame:
        columns = self.config["target"].get("columns", [])
        if not columns:
            self.logger.info("No target column mapping configured; using transformation output as-is.")
            return df

        select_columns = []
        for column in columns:
            target_name = column["name"]
            expression = column.get("expression") or column.get("source") or target_name
            data_type = column["data_type"]
            select_columns.append(F.expr(expression).cast(data_type).alias(target_name))
            self.logger.debug(
                "Column mapping target=%s expression=%s data_type=%s",
                target_name,
                expression,
                data_type,
            )

        aligned = df.select(*select_columns)
        self.logger.info("Aligned DataFrame to %d configured destination column(s).", len(columns))
        return aligned

    def _apply_static_audit_columns(self, df: DataFrame) -> DataFrame:
        audit = self.config.get("audit_columns", {})
        for column_name, expression in audit.items():
            df = df.withColumn(column_name, F.expr(expression))
            self.logger.info("Applied audit column=%s expression=%s", column_name, expression)
        return df

    def _load_target(self, spark: SparkSession, df: DataFrame) -> None:
        staging_view = self.config["load"].get("staging_view", f"stg_{self.name}")
        df.createOrReplaceTempView(staging_view)
        self.logger.info("Created staging view=%s for load.", staging_view)

        if self.load_method == "INSERT":
            if self.config["load"].get("truncate_before_insert", False):
                self.logger.info("Truncating target table before insert: %s", self.target_table)
                spark.sql(f"TRUNCATE TABLE {self.target_table}")
            sql_text = self._build_insert_sql(staging_view)
        elif self.load_method == "MERGE":
            sql_text = self._build_merge_sql(staging_view)
        else:
            raise ValueError(f"Unsupported load method: {self.load_method}")

        self.logger.debug("Executing load SQL for job=%s:\n%s", self.name, sql_text)
        spark.sql(sql_text)
        self.logger.info("Completed %s load into target=%s", self.load_method, self.target_table)

    def _build_insert_sql(self, staging_view: str) -> str:
        columns = self._target_column_names()
        column_csv = ", ".join(columns)
        insert_mode = self.config["load"].get("insert_mode", "INTO").upper()
        if insert_mode not in {"INTO", "OVERWRITE"}:
            raise ValueError(f"Unsupported insert_mode: {insert_mode}")

        return (
            f"INSERT {insert_mode} {self.target_table}\n"
            f"SELECT {column_csv}\n"
            f"FROM {staging_view}"
        )

    def _build_merge_sql(self, staging_view: str) -> str:
        columns = self._target_column_names()
        business_keys = self.config["load"]["business_keys"]
        update_columns = [col for col in columns if col not in business_keys]
        on_clause = " AND ".join([f"t.{key} = s.{key}" for key in business_keys])
        update_clause = ", ".join([f"t.{col} = s.{col}" for col in update_columns])
        insert_columns = ", ".join(columns)
        insert_values = ", ".join([f"s.{col}" for col in columns])

        return (
            f"MERGE INTO {self.target_table} t\n"
            f"USING {staging_view} s\n"
            f"ON {on_clause}\n"
            f"WHEN MATCHED THEN UPDATE SET {update_clause}\n"
            f"WHEN NOT MATCHED THEN INSERT ({insert_columns}) VALUES ({insert_values})"
        )

    def _generate_create_table_sql(self) -> str:
        target = self.config["target"]
        columns_sql = ",\n  ".join(
            [
                f"{column['name']} {column['data_type']}"
                + ("" if column.get("nullable", True) else " NOT NULL")
                for column in target.get("columns", [])
            ]
        )
        if not columns_sql:
            raise ValueError(
                f"Job {self.name} needs target.columns when create_table_sql_path is not provided."
            )

        table_format = target.get("format", "iceberg")
        partition_by = target.get("partition_by", [])
        partition_sql = f"\nPARTITIONED BY ({', '.join(partition_by)})" if partition_by else ""
        location_sql = f"\nLOCATION '{target['location']}'" if target.get("location") else ""
        properties = target.get("properties", {})
        properties_sql = ""
        if properties:
            properties_sql = "\nTBLPROPERTIES (" + ", ".join(
                [f"'{key}' = '{value}'" for key, value in properties.items()]
            ) + ")"

        return (
            f"CREATE TABLE IF NOT EXISTS {self.target_table} (\n"
            f"  {columns_sql}\n"
            f")\nUSING {table_format}"
            f"{partition_sql}"
            f"{location_sql}"
            f"{properties_sql}"
        )

    def _target_column_names(self) -> list[str]:
        columns = self.config["target"].get("columns", [])
        if not columns:
            raise ValueError(f"Job {self.name} requires target.columns for generic loading.")
        return [column["name"] for column in columns]

    def _table_exists(self, spark: SparkSession, table_name: str) -> bool:
        try:
            return spark.catalog.tableExists(table_name)
        except Exception:
            logging.getLogger(__name__).debug("Spark catalog.tableExists failed for %s", table_name)
            try:
                spark.sql(f"DESCRIBE TABLE {table_name}")
                return True
            except Exception:
                return False

    def _read_text(self, path: str | None) -> str:
        if not path:
            raise ValueError(f"Job {self.name} requires a SQL path.")
        resolved = Path(path)
        self.logger.info("Reading SQL file=%s", resolved)
        return resolved.read_text(encoding="utf-8")

    def _render_sql(self, sql_text: str) -> str:
        variables: dict[str, Any] = {
            "target_table": self.target_table,
            "job_name": self.name,
            **self.config.get("variables", {}),
        }
        return sql_text.format(**variables)

"""Config-driven Spark ETL framework for lakehouse pipelines."""

__version__ = "0.1.0"

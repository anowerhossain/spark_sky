from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_pipeline_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Pipeline config not found: {path}")

    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle) or {}

    _validate_config(config, path)
    return config


def _validate_config(config: dict[str, Any], path: Path) -> None:
    if "pipeline" not in config:
        raise ValueError(f"{path} must define a 'pipeline' section.")

    pipeline = config["pipeline"]
    if not pipeline.get("name"):
        raise ValueError(f"{path} pipeline.name is required.")

    jobs = pipeline.get("jobs")
    if not isinstance(jobs, list) or not jobs:
        raise ValueError(f"{path} pipeline.jobs must be a non-empty list.")

    seen: set[str] = set()
    for job in jobs:
        if not job.get("name"):
            raise ValueError("Every job must define a name.")
        if "sequence" not in job:
            raise ValueError(f"Job {job['name']} must define a sequence.")
        if not job.get("target", {}).get("table"):
            raise ValueError(f"Job {job['name']} must define target.table.")
        if not job.get("load", {}).get("method"):
            raise ValueError(f"Job {job['name']} must define load.method.")
        if job["name"] in seen:
            raise ValueError(f"Duplicate job name: {job['name']}")
        seen.add(job["name"])

    for job in jobs:
        for dependency in job.get("depends_on", []):
            if dependency not in seen:
                raise ValueError(f"Job {job['name']} depends on unknown job {dependency}.")

        method = job.get("load", {}).get("method", "").upper()
        if method not in {"INSERT", "MERGE"}:
            raise ValueError(f"Job {job['name']} load.method must be INSERT or MERGE.")
        if method == "MERGE" and not job.get("load", {}).get("business_keys"):
            raise ValueError(f"Job {job['name']} MERGE load requires load.business_keys.")

        api = job.get("transformation", {}).get("api", "spark_sql")
        if api not in {"spark_sql", "dataframe"}:
            raise ValueError(f"Job {job['name']} transformation.api must be spark_sql or dataframe.")

        create_sql_path = job.get("target", {}).get("create_table_sql_path")
        if create_sql_path and not Path(create_sql_path).exists():
            raise ValueError(
                f"Job {job['name']} target.create_table_sql_path does not exist: {create_sql_path}"
            )

        load_sql_path = job.get("transformation", {}).get("load_sql_path")
        if api == "spark_sql" and load_sql_path and not Path(load_sql_path).exists():
            raise ValueError(
                f"Job {job['name']} transformation.load_sql_path does not exist: {load_sql_path}"
            )

SELECT
  ca.customer_id,
  ca.full_name,
  ca.country,
  ca.currency,
  COUNT(DISTINCT ca.account_id) AS account_count,
  CAST(SUM(ca.balance) AS DECIMAL(18,2)) AS total_balance,
  CAST(COALESCE(SUM(td.debit_amount), 0) AS DECIMAL(18,2)) AS total_debit_amount,
  CAST(COALESCE(SUM(td.credit_amount), 0) AS DECIMAL(18,2)) AS total_credit_amount,
  current_timestamp() AS gold_loaded_at
FROM silver_customer_account ca
LEFT JOIN silver_transaction_daily td
  ON ca.account_id = td.account_id
 AND ca.currency = td.currency
GROUP BY
  ca.customer_id,
  ca.full_name,
  ca.country,
  ca.currency

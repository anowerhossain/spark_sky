SELECT
  CAST(a.account_id AS STRING) AS account_id,
  CAST(a.customer_id AS STRING) AS customer_id,
  CAST(c.full_name AS STRING) AS full_name,
  CAST(c.country AS STRING) AS country,
  CAST(a.branch_id AS STRING) AS branch_id,
  CAST(b.branch_name AS STRING) AS branch_name,
  CAST(a.product_id AS STRING) AS product_id,
  CAST(p.product_name AS STRING) AS product_name,
  CAST(p.product_family AS STRING) AS product_family,
  CAST(a.account_type AS STRING) AS account_type,
  CAST(a.account_open_date AS DATE) AS account_open_date,
  CAST(a.account_status AS STRING) AS account_status,
  CAST(a.balance AS DECIMAL(18,2)) AS balance,
  CAST(a.currency AS STRING) AS currency,
  current_timestamp() AS silver_loaded_at
FROM bronze_accounts a
INNER JOIN bronze_customers c
  ON a.customer_id = c.customer_id
LEFT JOIN bronze_branches b
  ON a.branch_id = b.branch_id
LEFT JOIN bronze_products p
  ON a.product_id = p.product_id
WHERE COALESCE(a.is_deleted, false) = false
  AND COALESCE(c.is_deleted, false) = false

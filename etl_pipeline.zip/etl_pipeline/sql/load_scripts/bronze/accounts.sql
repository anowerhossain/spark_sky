SELECT
  CAST(account_id AS STRING) AS account_id,
  CAST(customer_id AS STRING) AS customer_id,
  CAST(product_id AS STRING) AS product_id,
  CAST(branch_id AS STRING) AS branch_id,
  CAST(account_open_date AS DATE) AS account_open_date,
  CAST(account_type AS STRING) AS account_type,
  CAST(balance AS DECIMAL(18,2)) AS balance,
  CAST(currency AS STRING) AS currency,
  CAST(account_status AS STRING) AS account_status,
  CAST(is_deleted AS BOOLEAN) AS is_deleted
FROM raw_accounts

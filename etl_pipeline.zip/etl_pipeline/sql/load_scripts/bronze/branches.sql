SELECT
  CAST(branch_id AS STRING) AS branch_id,
  CAST(branch_name AS STRING) AS branch_name,
  CAST(city AS STRING) AS city,
  CAST(country AS STRING) AS country,
  CAST(is_active AS BOOLEAN) AS is_active
FROM raw_branches

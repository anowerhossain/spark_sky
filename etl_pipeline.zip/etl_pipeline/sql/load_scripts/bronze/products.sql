SELECT
  CAST(product_id AS STRING) AS product_id,
  CAST(product_name AS STRING) AS product_name,
  CAST(product_family AS STRING) AS product_family,
  CAST(risk_level AS STRING) AS risk_level
FROM raw_products

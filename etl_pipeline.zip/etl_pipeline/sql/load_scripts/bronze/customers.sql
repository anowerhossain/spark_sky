SELECT
  CAST(customer_id AS STRING) AS customer_id,
  CAST(full_name AS STRING) AS full_name,
  CAST(country AS STRING) AS country,
  CAST(kyc_status AS STRING) AS kyc_status,
  CAST(branch_id AS STRING) AS branch_id,
  CAST(is_deleted AS BOOLEAN) AS is_deleted
FROM raw_customers

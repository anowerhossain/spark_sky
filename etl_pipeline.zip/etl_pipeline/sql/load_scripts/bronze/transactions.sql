SELECT
  CAST(transaction_id AS STRING) AS transaction_id,
  CAST(account_id AS STRING) AS account_id,
  CAST(transaction_date AS DATE) AS transaction_date,
  CAST(dr_cr AS STRING) AS dr_cr,
  CAST(amount AS DECIMAL(18,2)) AS amount,
  CAST(currency AS STRING) AS currency,
  CAST(transaction_status AS STRING) AS transaction_status,
  CAST(channel AS STRING) AS channel,
  CAST(is_deleted AS BOOLEAN) AS is_deleted
FROM raw_transactions

CREATE TABLE IF NOT EXISTS {target_table} (
  account_id STRING,
  customer_id STRING,
  product_id STRING,
  branch_id STRING,
  account_open_date DATE,
  account_type STRING,
  balance DECIMAL(18,2),
  currency STRING,
  account_status STRING,
  is_deleted BOOLEAN
)
USING iceberg
TBLPROPERTIES ('format-version' = '2')

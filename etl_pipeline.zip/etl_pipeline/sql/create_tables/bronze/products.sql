CREATE TABLE IF NOT EXISTS {target_table} (
  product_id STRING,
  product_name STRING,
  product_family STRING,
  risk_level STRING
)
USING iceberg
TBLPROPERTIES ('format-version' = '2')

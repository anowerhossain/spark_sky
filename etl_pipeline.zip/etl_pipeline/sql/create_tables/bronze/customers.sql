CREATE TABLE IF NOT EXISTS {target_table} (
  customer_id STRING,
  full_name STRING,
  country STRING,
  kyc_status STRING,
  branch_id STRING,
  is_deleted BOOLEAN
)
USING iceberg
TBLPROPERTIES ('format-version' = '2')

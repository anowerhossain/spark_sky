CREATE TABLE IF NOT EXISTS {target_table} (
  branch_id STRING,
  branch_name STRING,
  city STRING,
  country STRING,
  is_active BOOLEAN
)
USING iceberg
TBLPROPERTIES ('format-version' = '2')

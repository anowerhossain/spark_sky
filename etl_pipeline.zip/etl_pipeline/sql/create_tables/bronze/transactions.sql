CREATE TABLE IF NOT EXISTS {target_table} (
  transaction_id STRING,
  account_id STRING,
  transaction_date DATE,
  dr_cr STRING,
  amount DECIMAL(18,2),
  currency STRING,
  transaction_status STRING,
  channel STRING,
  is_deleted BOOLEAN
)
USING iceberg
PARTITIONED BY (transaction_date)
TBLPROPERTIES ('format-version' = '2')

CREATE TABLE IF NOT EXISTS {target_table} (
  account_id STRING,
  customer_id STRING,
  full_name STRING,
  country STRING,
  branch_id STRING,
  branch_name STRING,
  product_id STRING,
  product_name STRING,
  product_family STRING,
  account_type STRING,
  account_open_date DATE,
  account_status STRING,
  balance DECIMAL(18,2),
  currency STRING,
  silver_loaded_at TIMESTAMP
)
USING iceberg
PARTITIONED BY (country)
TBLPROPERTIES (
  'format-version' = '2',
  'write.delete.mode' = 'merge-on-read',
  'write.update.mode' = 'merge-on-read',
  'write.merge.mode' = 'merge-on-read'
)

CREATE TABLE IF NOT EXISTS {target_table} (
  account_id STRING,
  transaction_date DATE,
  currency STRING,
  debit_amount DECIMAL(18,2),
  credit_amount DECIMAL(18,2),
  transaction_count BIGINT,
  silver_loaded_at TIMESTAMP
)
USING iceberg
PARTITIONED BY (transaction_date)
TBLPROPERTIES (
  'format-version' = '2',
  'write.delete.mode' = 'merge-on-read',
  'write.update.mode' = 'merge-on-read',
  'write.merge.mode' = 'merge-on-read'
)

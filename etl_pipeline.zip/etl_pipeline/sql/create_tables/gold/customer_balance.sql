CREATE TABLE IF NOT EXISTS {target_table} (
  customer_id STRING,
  full_name STRING,
  country STRING,
  currency STRING,
  account_count BIGINT,
  total_balance DECIMAL(18,2),
  total_debit_amount DECIMAL(18,2),
  total_credit_amount DECIMAL(18,2),
  gold_loaded_at TIMESTAMP
)
USING iceberg
PARTITIONED BY (country)
TBLPROPERTIES ('format-version' = '2')

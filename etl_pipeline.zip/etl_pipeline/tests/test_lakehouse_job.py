from etl_pipeline.jobs.lakehouse import ConfigDrivenLakehouseJob


def _job_config(load):
    return {
        "name": "customer_account",
        "target": {
            "table": "bank.silver.customer_account",
            "format": "iceberg",
            "partition_by": ["country"],
            "columns": [
                {"name": "account_id", "data_type": "string", "nullable": False},
                {"name": "customer_id", "data_type": "string", "nullable": False},
                {"name": "country", "data_type": "string"},
                {"name": "balance", "data_type": "decimal(18,2)"},
            ],
        },
        "load": load,
    }


def test_build_insert_sql():
    job = ConfigDrivenLakehouseJob(
        _job_config({"method": "INSERT", "insert_mode": "OVERWRITE"})
    )

    sql = job._build_insert_sql("stg_customer_account")

    assert "INSERT OVERWRITE bank.silver.customer_account" in sql
    assert "SELECT account_id, customer_id, country, balance" in sql
    assert "FROM stg_customer_account" in sql


def test_build_merge_sql_uses_business_keys():
    job = ConfigDrivenLakehouseJob(
        _job_config({"method": "MERGE", "business_keys": ["account_id"]})
    )

    sql = job._build_merge_sql("stg_customer_account")

    assert "MERGE INTO bank.silver.customer_account t" in sql
    assert "ON t.account_id = s.account_id" in sql
    assert "t.customer_id = s.customer_id" in sql
    assert "WHEN NOT MATCHED THEN INSERT" in sql


def test_generate_create_table_sql_defaults_to_iceberg():
    job = ConfigDrivenLakehouseJob(_job_config({"method": "INSERT"}))

    sql = job._generate_create_table_sql()

    assert "CREATE TABLE IF NOT EXISTS bank.silver.customer_account" in sql
    assert "account_id string NOT NULL" in sql
    assert "USING iceberg" in sql
    assert "PARTITIONED BY (country)" in sql

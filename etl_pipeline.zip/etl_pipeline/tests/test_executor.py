from etl_pipeline.core.executor import PipelineExecutor


def test_executor_plans_parallel_levels():
    config = {
        "pipeline": {
            "name": "test",
            "jobs": [
                {
                    "name": "a",
                    "sequence": 10,
                    "target": {"table": "bank.silver.a"},
                    "load": {"method": "INSERT"},
                },
                {
                    "name": "b",
                    "sequence": 10,
                    "target": {"table": "bank.silver.b"},
                    "load": {"method": "INSERT"},
                },
                {
                    "name": "c",
                    "sequence": 20,
                    "depends_on": ["a", "b"],
                    "target": {"table": "bank.gold.c"},
                    "load": {"method": "INSERT"},
                },
            ],
        }
    }

    assert PipelineExecutor(config).plan() == [["a", "b"], ["c"]]


def test_executor_selects_target_upstreams_only():
    config = {
        "pipeline": {
            "name": "test",
            "jobs": [
                {
                    "name": "a",
                    "sequence": 10,
                    "target": {"table": "bank.silver.a"},
                    "load": {"method": "INSERT"},
                },
                {
                    "name": "b",
                    "sequence": 10,
                    "target": {"table": "bank.silver.b"},
                    "load": {"method": "INSERT"},
                },
                {
                    "name": "c",
                    "sequence": 20,
                    "depends_on": ["a"],
                    "target": {"table": "bank.gold.c"},
                    "load": {"method": "INSERT"},
                },
            ],
        }
    }

    assert PipelineExecutor(config).plan(target_job="c") == [["a"], ["c"]]


def test_executor_rejects_dependency_in_same_or_later_sequence():
    config = {
        "pipeline": {
            "name": "test",
            "jobs": [
                {
                    "name": "a",
                    "sequence": 20,
                    "target": {"table": "bank.silver.a"},
                    "load": {"method": "INSERT"},
                },
                {
                    "name": "b",
                    "sequence": 10,
                    "depends_on": ["a"],
                    "target": {"table": "bank.silver.b"},
                    "load": {"method": "INSERT"},
                },
            ],
        }
    }

    try:
        PipelineExecutor(config)
    except ValueError as exc:
        assert "sequence must be greater" in str(exc)
    else:
        raise AssertionError("Expected invalid dependency sequence to be rejected.")
